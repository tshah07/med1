<?php
return array(
	'crypto_key' => 'ajo2kUScob7gz-YRng-HkQQI',
	'crypto_iv' => 'xzouycfZIh6ob3MtT8yEw1p0',
	'crypto_hmac' => 'KxgPogtSU8kUqBA-wQ3HEIvU',
);
