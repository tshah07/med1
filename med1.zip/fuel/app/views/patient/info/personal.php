<!--<ul class="nav nav-pills">-->
<!--	<li class='--><?php //echo Arr::get($subnav, "personal" ); ?><!--'>--><?php //echo Html::anchor('patient\info/personal','Personal');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "spouce" ); ?><!--'>--><?php //echo Html::anchor('patient\info/spouce','Spouce');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "emergency_contact" ); ?><!--'>--><?php //echo Html::anchor('patient\info/emergency_contact','Emergency contact');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "insurance" ); ?><!--'>--><?php //echo Html::anchor('patient\info/insurance','Insurance');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "financial_responsibility" ); ?><!--'>--><?php //echo Html::anchor('patient\info/financial_responsibility','Financial responsibility');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "pharmacy_info" ); ?><!--'>--><?php //echo Html::anchor('patient\info/pharmacy_info','Pharmacy info');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "health" ); ?><!--'>--><?php //echo Html::anchor('patient\info/health','Health');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "allergies" ); ?><!--'>--><?php //echo Html::anchor('patient\info/allergies','Allergies');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "medications" ); ?><!--'>--><?php //echo Html::anchor('patient\info/medications','Medications');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "past_sergical_history" ); ?><!--'>--><?php //echo Html::anchor('patient\info/past_sergical_history','Past sergical history');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "height_and_weight" ); ?><!--'>--><?php //echo Html::anchor('patient\info/height_and_weight','Height and weight');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "social_history" ); ?><!--'>--><?php //echo Html::anchor('patient\info/social_history','Social history');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "family_medical_history" ); ?><!--'>--><?php //echo Html::anchor('patient\info/family_medical_history','Family medical history');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "personal_review_of_systems" ); ?><!--'>--><?php //echo Html::anchor('patient\info/personal_review_of_systems','Personal review of systems');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "gynecological_review" ); ?><!--'>--><?php //echo Html::anchor('patient\info/gynecological_review','Gynecological review');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "authorization" ); ?><!--'>--><?php //echo Html::anchor('patient\info/authorization','Authorization');?><!--</li>-->
<!--	<li class='--><?php //echo Arr::get($subnav, "additonal_comments" ); ?><!--'>--><?php //echo Html::anchor('patient\info/additonal_comments','Additonal comments');?><!--</li>-->
<!---->
<!--</ul>-->


<!-- Start body-->
<div class="box  box-color box-bordered box-condensed nopadding">
    <div class="box-title">
        <h3> Basic Info </h3>
    </div>
<div class="box-content">
    <form class="form-inline form-horizontal form-striped ">
        <div class="row-fluid">

            <div class="span6">
                <div class="control-group">
                    <label for="firstName" class="control-label">First Name </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="firstName">
                    </div>

                     <label for="middleName" class="control-label">Middle Name </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="middleName">
                    </div>

                    <label for="lastName" class="control-label">Last Name </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="lastName">
                    </div>
                </div>

               

                <div class="control-group">
                    <label for="date_of_birth" class="control-label">Date Of Birth </label>
                    <div class="controls">
                        <input type="text" class="input-small datepick" name="date_of_birth">
                    </div>


                    <label for="gender" class="control-label">Gender </label>
                    <div class="controls">
                        <select class="input-medium select2" name="gender">
                            <option value="male">Male</option>
                            <option value="male">Female</option>
                            <option value="dont_want_to_specify">I don't want to specify</option>
                        </select>
                    </div>
                </div>

               

                <div class="control-group">
                    <label for="address_line" class="control-label">Address Line </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="address_line">
                    </div>

                    <label for="city" class="control-label">City </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="city">
                    </div>

                    <label for="state" class="control-label">State </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="state">
                    </div>

                    <label for="postal_code" class="control-label">Postal Code </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="postal_code">
                    </div>
                </div>

                

            </div>



            <!--           Second Coloumn start  -->
            <div class="span6">
                <div class="control-group">
                    <label for="email" class="control-label">Email </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="email">
                    </div>

                     <label for="cell_phone" class="control-label">Phone </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="cell_phone">
                    </div>

                    <label for="home_phone" class="control-label">Home Phone </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="home_phone">
                    </div>

                    <label for="work_phone" class="control-label">Work Phone </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="work_phone">
                    </div>
                </div>

                

                <div class="control-group">
                    <label for="date_of_birth" class="control-label">Date Of Birth </label>
                    <div class="controls">
                        <input type="text" class="input-medium datepick" name="date_of_birth">
                    </div>
                </div>

                <div class="control-group">
                    <label for="gender" class="control-label">Gender </label>
                    <div class="controls">
                        <select class="input-medium select2" name="gender">
                            <option value="male">Male</option>
                            <option value="male">Female</option>
                            <option value="dont_want_to_specify">I don't want to specify</option>
                        </select>
                    </div>
                </div>

               

                <div class="control-group">
                    <label for="address_line" class="control-label">Address Line </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="address_line">
                    </div>

                    <label for="city" class="control-label">City </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="city">
                    </div>

                    <label for="state" class="control-label">State </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="state">
                    </div>

                    <label for="postal_code" class="control-label">Postal Code </label>
                    <div class="controls">
                        <input type="text" class="input-medium" name="postal_code">
                    </div>
                </div>

                

            </div>

            <!--            Second Coloumn End  -->



        </div>
    </form>
</div>
</div>