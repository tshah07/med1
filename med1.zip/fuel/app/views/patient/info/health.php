<ul class="nav nav-pills">
	<li class='<?php echo Arr::get($subnav, "personal" ); ?>'><?php echo Html::anchor('patient\info/personal','Personal');?></li>
	<li class='<?php echo Arr::get($subnav, "spouce" ); ?>'><?php echo Html::anchor('patient\info/spouce','Spouce');?></li>
	<li class='<?php echo Arr::get($subnav, "emergency_contact" ); ?>'><?php echo Html::anchor('patient\info/emergency_contact','Emergency contact');?></li>
	<li class='<?php echo Arr::get($subnav, "insurance" ); ?>'><?php echo Html::anchor('patient\info/insurance','Insurance');?></li>
	<li class='<?php echo Arr::get($subnav, "financial_responsibility" ); ?>'><?php echo Html::anchor('patient\info/financial_responsibility','Financial responsibility');?></li>
	<li class='<?php echo Arr::get($subnav, "pharmacy_info" ); ?>'><?php echo Html::anchor('patient\info/pharmacy_info','Pharmacy info');?></li>
	<li class='<?php echo Arr::get($subnav, "health" ); ?>'><?php echo Html::anchor('patient\info/health','Health');?></li>
	<li class='<?php echo Arr::get($subnav, "allergies" ); ?>'><?php echo Html::anchor('patient\info/allergies','Allergies');?></li>
	<li class='<?php echo Arr::get($subnav, "medications" ); ?>'><?php echo Html::anchor('patient\info/medications','Medications');?></li>
	<li class='<?php echo Arr::get($subnav, "past_sergical_history" ); ?>'><?php echo Html::anchor('patient\info/past_sergical_history','Past sergical history');?></li>
	<li class='<?php echo Arr::get($subnav, "height_and_weight" ); ?>'><?php echo Html::anchor('patient\info/height_and_weight','Height and weight');?></li>
	<li class='<?php echo Arr::get($subnav, "social_history" ); ?>'><?php echo Html::anchor('patient\info/social_history','Social history');?></li>
	<li class='<?php echo Arr::get($subnav, "family_medical_history" ); ?>'><?php echo Html::anchor('patient\info/family_medical_history','Family medical history');?></li>
	<li class='<?php echo Arr::get($subnav, "personal_review_of_systems" ); ?>'><?php echo Html::anchor('patient\info/personal_review_of_systems','Personal review of systems');?></li>
	<li class='<?php echo Arr::get($subnav, "gynecological_review" ); ?>'><?php echo Html::anchor('patient\info/gynecological_review','Gynecological review');?></li>
	<li class='<?php echo Arr::get($subnav, "authorization" ); ?>'><?php echo Html::anchor('patient\info/authorization','Authorization');?></li>
	<li class='<?php echo Arr::get($subnav, "additonal_comments" ); ?>'><?php echo Html::anchor('patient\info/additonal_comments','Additonal comments');?></li>

</ul>
<p>Health</p>