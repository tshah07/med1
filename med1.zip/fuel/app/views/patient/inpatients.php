<ul class="nav nav-pills">
	
	<li class='<?php echo Arr::get($subnav, "show_all" ); ?>'><?php echo Html::anchor('patient/show_all','Show all');?></li>
	<li class='<?php echo Arr::get($subnav, "find_a_patient" ); ?>'><?php echo Html::anchor('patient/find_a_patient','Find a patient');?></li>
	<li class='<?php echo Arr::get($subnav, "inpatients" ); ?>'><?php echo Html::anchor('patient/inpatients','Inpatients');?></li>
	<li class='<?php echo Arr::get($subnav, "outpatients" ); ?>'><?php echo Html::anchor('patient/outpatients','Outpatients');?></li>
	<li class='<?php echo Arr::get($subnav, "new_patient" ); ?>'><?php echo Html::anchor('patient/new_patient','New patient');?></li>

</ul>
<p>Inpatients</p>