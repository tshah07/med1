<h2>New Page</h2>
<br>

<?php echo render('admin\pages/_form'); ?>


<p><?php echo Html::anchor('admin/pages', 'Back'); ?></p>
