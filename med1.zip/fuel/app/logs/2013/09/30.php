<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2013-09-30 03:51:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2013-09-30 03:52:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
